# Get COCO validation JSON as example
wget https://github.com/tylin/coco-caption/raw/master/annotations/captions_val2014.json

